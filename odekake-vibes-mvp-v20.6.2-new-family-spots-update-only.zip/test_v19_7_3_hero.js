const fs = require('fs');
const assert = require('assert');
const seed = JSON.parse(fs.readFileSync('seed.json','utf8'));
const audit = JSON.parse(fs.readFileSync('HERO_OVERRIDES_v19_7_3.json','utf8'));
const byId = Object.fromEntries(seed.spots.map(s => [s.spot_id, s]));
assert.ok(/^(?:0\.19\.(?:7\.3|8(?:\.\d+)?|9)|0\.20\.\d+(?:\.\d+)?(?:\.\d+)?)$/.test(seed.metadata.version));
assert.ok(seed.spots.length>=291);
assert.equal(Object.keys(audit.photo_index_overrides).length, 29);
assert.equal(Object.keys(audit.place_overrides).length, 4);
for (const [id, idx] of Object.entries(audit.photo_index_overrides)) {
  assert.equal(byId[id].media_strategy.google_places.photo_index_override, idx, id);
}
for (const [id, p] of Object.entries(audit.place_overrides)) {
  const gp = byId[id].media_strategy.google_places;
  assert.equal(gp.place_id, p.place_id, id);
  assert.equal(gp.status, 'resolved_manual', id);
  assert.equal(gp.matched_name, p.matched_name, id);
  assert.equal(gp.matched_address, p.matched_address, id);
  assert.equal(gp.use_address, p.use_address, id);
  assert.equal(byId[id].routing.google_place_id, p.place_id, id);
}
const photoCount = seed.spots.filter(s => Number.isInteger(s?.media_strategy?.google_places?.photo_index_override)).length;
const placeIdCount = seed.spots.filter(s => !!s?.media_strategy?.google_places?.place_id).length;
assert.ok(photoCount >= 182, `expected at least 182 photo overrides, got ${photoCount}`);
assert.ok(placeIdCount >= 62, `expected at least 62 Place IDs, got ${placeIdCount}`);
console.log(`V19.7.3 Hero PASS: baseline audit preserved; totals ${photoCount} photo overrides / ${placeIdCount} Place IDs`);
