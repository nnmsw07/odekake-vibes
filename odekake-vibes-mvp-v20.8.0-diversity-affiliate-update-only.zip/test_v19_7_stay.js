const assert=require('assert');
const fs=require('fs');
const path=require('path');
const R=require('./recommender.js');
const root=__dirname;
const seed=JSON.parse(fs.readFileSync(path.join(root,'seed.json'),'utf8'));
const byId=Object.fromEntries(seed.spots.map(s=>[s.spot_id,s]));
assert.ok(/^(?:0\.19\.(?:7(?:\.\d+)?|8(?:\.\d+)?|9)|0\.20\.\d+(?:\.\d+)?(?:\.\d+)?)$/.test(seed.metadata.version));
assert.ok(seed.spots.length>=291);
for(let i=212;i<=241;i++){
  const id=`spot_${String(i).padStart(3,'0')}`;
  assert.ok(byId[id],`missing ${id}`);
  assert.equal(byId[id].overnight,true,`${id} overnight`);
  assert.equal(byId[id].category_primary,'hotel_stay',`${id} category`);
  assert.ok(byId[id].stay_profile?.overnight,`${id} stay profile`);
  assert.ok(byId[id].media_strategy?.hero_priority?.includes('google_places'),`${id} places-first hero`);
  assert.equal(byId[id].media_strategy?.current_provider,'ai',`${id} AI fallback`);
}
assert.equal(byId.spot_238.name,'赤沢温泉ホテル');
assert.equal(byId.spot_238.prefecture,'静岡県');
assert.ok(byId.spot_238.official_url.includes('izuakazawa.jp'));
const index=fs.readFileSync(path.join(root,'index.html'),'utf8');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const rec=fs.readFileSync(path.join(root,'recommender.js'),'utf8');
assert.ok(index.includes('id="stayModeSelect"'));
assert.ok(index.includes('泊まりもあり'));
assert.ok(app.includes("['izu','伊豆']"));
assert.ok(app.includes("['stay','泊まる・ホテル']"));
assert.ok(app.includes('allowOvernight'));
assert.ok(rec.includes("spot.overnight&&!ctx.allowOvernight"));
const base={selectedVibes:['relax','extraordinary'],audience:'partner',weather:'any',availableMinutes:1440,currentDate:'2026-08-30T12:00:00+09:00'};
let r=R.recommend(seed,{...base,allowOvernight:false});
const hotelIds=new Set(seed.spots.filter(s=>s.overnight).map(s=>s.spot_id));
assert.ok(!r.recommendations.some(x=>hotelIds.has(x.spot_id)),'day mode must not recommend hotels');
assert.ok(r.excluded.some(x=>x.spot_id==='spot_212'),'day mode should hard-filter hotels');
r=R.recommend(seed,{...base,allowOvernight:true});
assert.ok(r.recommendations.some(x=>hotelIds.has(x.spot_id)),`stay mode should surface a hotel: ${r.recommendations.map(x=>x.name).join(', ')}`);
for(const slug of ['hakone-stay','izu-stay']){
  const p=path.join(root,'guide',slug,'index.html');
  assert.ok(fs.existsSync(p),`missing guide ${slug}`);
  const h=fs.readFileSync(p,'utf8');
  assert.ok(h.includes('<link rel="canonical"'),`canonical ${slug}`);
  assert.ok(h.includes('G-M99DNGD18F'),`GA4 ${slug}`);
}
const guideData=JSON.parse(fs.readFileSync(path.join(root,'SEO_GUIDES_v19_7.json'),'utf8')).guides;
assert.equal(guideData.length,22,'22 guides total');
const sm=fs.readFileSync(path.join(root,'sitemap.xml'),'utf8');
assert.ok(sm.includes('https://kibuntrip.com/guide/hakone-stay/'));
assert.ok(sm.includes('https://kibuntrip.com/guide/izu-stay/'));
const aff=fs.readFileSync(path.join(root,'affiliate-config.js'),'utf8');
assert.ok(/[\"']?enabled[\"']?\s*:\s*true/.test(aff),'affiliate enabled');
for(const i of [212,213,214,215,217]) assert.ok(aff.includes(`"spot_${i}"`),`Hakone individual affiliate ${i}`);
// Later sweeps may add a hotel only after a facility-specific booking page is verified.
for(const i of [216,218,219,220,221,222,223,224,225,226,227,228,229,231,232,234,236,237,239,240]) assert.ok(aff.includes(`"spot_${i}"`),`verified hotel affiliate ${i}`);
for(const i of [230,233,235,238,241]) assert.ok(!aff.includes(`"spot_${i}"`),`unverified hotel affiliate must remain absent spot_${i}`);
assert.ok(!aff.includes('LRG_141600'),'legacy Hakone area fallback must be removed');
assert.ok(!aff.includes('a8mat=4BAI1K+EJC1IQ+14CS+BW8O2'),'legacy A8 area link must be removed');
console.log('V19.7 STAY PASS: 30 hotels + day/stay hard filter + Izu browse + 2 stay guides + individual booking links');
