#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
MANIFEST="UPDATE_MANIFEST_v20_19_1.txt"
ARCHIVE="kibun-v20.19.1-mood-magazine-hotfix.zip"

[[ -d .git ]] || { echo "ERROR: run this from the Kibun repository root in Codespaces."; exit 1; }
[[ -f "$MANIFEST" ]] || { echo "ERROR: $MANIFEST not found."; exit 1; }
for f in index.html en/index.html styles.css en/styles.css magazine/magazine.css magazine/magazine-media.js test_v20_19_1_ui_magazine_hotfix.js test_v20_19_0_mood_content_overrides.js; do
  [[ -f "$f" ]] || { echo "ERROR: update file missing: $f"; exit 1; }
done

cleanup_update_files() {
  for f in "$MANIFEST" "$0" "$ARCHIVE"; do
    [[ -e "$f" ]] || continue
    if git ls-files --error-unmatch "$f" >/dev/null 2>&1; then
      git restore --source=HEAD -- "$f"
    else
      rm -f "$f"
    fi
  done
}
trap 'echo "Update stopped before push because a check failed."' ERR

echo "[1/4] Syntax and v20.19.1 UI/article checks"
node --check magazine/magazine-media.js >/dev/null
node --check scripts/generate_en_pages.mjs >/dev/null
node test_v20_19_1_ui_magazine_hotfix.js
node test_v20_19_0_mood_content_overrides.js

echo "[2/4] Regression and SEO audits"
node test_recommender.js
node test_v20_11_25_ui_ogp.js
node scripts/event_audit.mjs
node scripts/performance_audit.mjs
node scripts/seo_audit.mjs

echo "[3/4] Stage v20.19.1 hotfix files"
mapfile -t FILES < "$MANIFEST"
for f in "${FILES[@]}"; do
  [[ -e "$f" ]] || { echo "ERROR: expected file missing: $f"; exit 1; }
done
git add -- "${FILES[@]}"

if git diff --cached --quiet; then
  echo "Kibun v20.19.1 is already applied; nothing to push."
  trap - ERR
  cleanup_update_files
  exit 0
fi

echo "[4/4] Commit and push"
git commit -m "Kibun v20.19.1: fix mood cards and feature article layout"
git push origin main

trap - ERR
cleanup_update_files
echo "Kibun v20.19.1 pushed. Cloudflare will deploy automatically from GitHub."
