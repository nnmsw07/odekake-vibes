#!/usr/bin/env bash
set -euo pipefail

UPDATE_ZIP="${KIBUN_UPDATE_ZIP:-kibun-v20.11.18-hero-rescue.zip}"
COMMIT_MESSAGE="Rescue Kibun hero images and deploy Places fix"

if ! git rev-parse --show-toplevel >/dev/null 2>&1; then
  echo "ERROR: Run this from inside the Kibun Git repository." >&2
  exit 1
fi
ROOT="$(git rev-parse --show-toplevel)"
cd "$ROOT"

if [[ -f "$UPDATE_ZIP" ]]; then
  echo "==> Applying $UPDATE_ZIP"
  unzip -oq "$UPDATE_ZIP" -d .
else
  echo "ERROR: $UPDATE_ZIP not found in repository root." >&2
  exit 1
fi

echo "==> Syntax checks"
node --check app.js
node --check media.js
node --check magazine/magazine-media.js
node --check worker/worker.js

echo "==> Hero regression checks"
node test_v20_11_18_hero_rescue.js
node test_v20_11_17_hero_hardening.js
node test_v20_10_2_magazine_hotfix.js
node test_v20_3_3_plan_and_magazine.js
node test_v20_10_1_hero_audit.js
node test_v20_8_2_hero_audit.js

git diff --check

if [[ "${KIBUN_SKIP_WORKER_DEPLOY:-0}" != "1" ]]; then
  echo "==> Deploying Cloudflare Worker (required for the Places Hero fix)"
  (cd worker && npx --yes wrangler deploy)
else
  echo "==> Skipping Worker deploy because KIBUN_SKIP_WORKER_DEPLOY=1"
fi

echo "==> Staging v20.11.18 files"
git add -- \
  seed.json \
  data.js \
  app.js \
  media.js \
  worker/worker.js \
  styles.css \
  index.html \
  images/ai/terrace-evening-generic.webp \
  CHANGELOG_v20_11_18.md \
  HANDOFF_v20_11_18.md \
  APPLY_v20_11_18.md \
  test_v20_11_18_hero_rescue.js \
  test_v20_11_17_hero_hardening.js \
  apply_update.sh

if git diff --cached --quiet; then
  echo "No v20.11.18 changes to commit."
  exit 0
fi

echo "==> Committing"
git commit -m "$COMMIT_MESSAGE"

echo "==> Pushing to origin/main"
git push origin main

echo "==> Done: v20.11.18 Hero rescue is pushed and Worker is deployed."
