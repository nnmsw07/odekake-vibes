#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
MANIFEST="UPDATE_MANIFEST_v20_19_2.txt"
ARCHIVE="kibun-v20.19.2-venue-magazine-hero-hotfix.zip"

[[ -d .git ]] || { echo "ERROR: run this from the Kibun repository root in Codespaces."; exit 1; }
[[ -f "$MANIFEST" ]] || { echo "ERROR: $MANIFEST not found."; exit 1; }
for f in index.html en/index.html app.js en/app.js styles.css magazine/magazine.css magazine/magazine-media.js whats-on/app.js en/whats-on/app.js test_v20_19_2_venue_hero_hotfix.js scripts/sync_magazine_hero_media.py; do
  [[ -f "$f" ]] || { echo "ERROR: update file missing: $f"; exit 1; }
done

cleanup_update_files() {
  for f in "$MANIFEST" "$0" "$ARCHIVE"; do
    [[ -e "$f" ]] || continue
    if git ls-files --error-unmatch "$f" >/dev/null 2>&1; then
      git restore --source=HEAD -- "$f"
    else
      rm -f "$f"
    fi
  done
}
trap 'echo "Update stopped before push because a check failed."' ERR

echo "[1/4] Sync magazine hero media and run syntax/UI checks"
python scripts/sync_magazine_hero_media.py
node --check app.js >/dev/null
node --check en/app.js >/dev/null
node --check whats-on/app.js >/dev/null
node --check en/whats-on/app.js >/dev/null
node --check magazine/magazine-media.js >/dev/null
node test_v20_19_2_venue_hero_hotfix.js

echo "[2/4] Regression, event, performance and SEO audits"
node test_recommender.js
node scripts/event_audit.mjs
node scripts/performance_audit.mjs
node scripts/seo_audit.mjs

echo "[3/4] Stage v20.19.2 files"
mapfile -t FILES < "$MANIFEST"
for f in "${FILES[@]}"; do
  [[ -e "$f" ]] || { echo "ERROR: expected file missing: $f"; exit 1; }
done
git add -- "${FILES[@]}"

if git diff --cached --quiet; then
  echo "Kibun v20.19.2 is already applied; nothing to push."
  trap - ERR
  cleanup_update_files
  exit 0
fi

echo "[4/4] Commit and push"
git commit -m "Kibun v20.19.2: fix feature heroes and venue whats-on"
git push origin main

trap - ERR
cleanup_update_files
echo "Kibun v20.19.2 pushed. Cloudflare will deploy automatically from GitHub."
