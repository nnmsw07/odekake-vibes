#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
MANIFEST="UPDATE_MANIFEST_v20_14_0.txt"

[[ -f "$MANIFEST" ]] || { echo "ERROR: $MANIFEST not found"; exit 1; }
[[ -f seed.json && -f en/app.js && -f test_v20_14_0_family_en_parity.js ]] || { echo "ERROR: update files are incomplete"; exit 1; }

node --check en/app.js >/dev/null
node scripts/generate_en_pages.mjs >/dev/null
node scripts/generate_seo_pages.mjs >/dev/null
node test_v20_14_0_family_en_parity.js

mapfile -t FILES < "$MANIFEST"
for f in "${FILES[@]}"; do
  [[ -e "$f" ]] || { echo "ERROR: missing $f"; exit 1; }
done

git add -- "${FILES[@]}"
if git diff --cached --quiet; then
  echo "Kibun v20.14.0 is already applied."
  rm -f "$MANIFEST" "$0"
  exit 0
fi

git commit -m "Kibun v20.14.0: family spots and English parity"
git push origin main

rm -f "$MANIFEST" "$0"
echo "Kibun v20.14.0 pushed. Cloudflare will deploy from GitHub automatically."
