#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(git rev-parse --show-toplevel)"
cd "$ROOT"
mkdir -p scripts
cp "$HERE/scripts/generate_seo_pages.mjs" scripts/generate_seo_pages.mjs
cp "$HERE/CHANGELOG_v20_11_20.md" CHANGELOG_v20_11_20.md
node scripts/generate_seo_pages.mjs
git add scripts/generate_seo_pages.mjs CHANGELOG_v20_11_20.md spots sitemap.xml robots.txt
if git diff --cached --quiet; then
  echo "変更はありません。"
  exit 0
fi
git commit -m "feat: add indexable spot routes and sitemap"
git push origin HEAD
echo "完了: push 後は Cloudflare の GitHub 連携で自動デプロイされます。"
