Kibun v20.11.20 SEO update

Codespaces では、ZIPをリポジトリ直下へアップロードしてから案内された1コマンドを実行してください。
apply_update.sh は Cloudflare のログインや wrangler deploy を行いません。
