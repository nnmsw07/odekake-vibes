#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
MANIFEST="UPDATE_MANIFEST_v20_16_0.txt"
ARCHIVE="kibun-v20.16.0-whats-on-events-update.zip"

[[ -d .git ]] || { echo "ERROR: run this from the Kibun repository root in Codespaces."; exit 1; }
[[ -f "$MANIFEST" ]] || { echo "ERROR: $MANIFEST not found."; exit 1; }
for f in seed.json data.js events.json events.js whats-on/index.html en/whats-on/index.html scripts/event_audit.mjs test_v20_16_0_whats_on.js; do
  [[ -f "$f" ]] || { echo "ERROR: update file missing: $f"; exit 1; }
done

cleanup_update_files() {
  for f in "$MANIFEST" "$0" "$ARCHIVE" "seo-audit/v20.16.0-final.json" "seo-audit/v20.16.0-final.md"; do
    [[ -e "$f" ]] || continue
    if git ls-files --error-unmatch "$f" >/dev/null 2>&1; then
      git restore --source=HEAD -- "$f"
    else
      rm -f "$f"
    fi
  done
}
trap 'echo "Update stopped before push because a check failed."' ERR

echo "[1/5] Syntax checks"
node --check app.js >/dev/null
node --check en/app.js >/dev/null
node --check whats-on/app.js >/dev/null
node --check en/whats-on/app.js >/dev/null
node --check performances/app.js >/dev/null
node --check en/performances/app.js >/dev/null
node --check scripts/generate_en_pages.mjs >/dev/null
node --check scripts/generate_seo_pages.mjs >/dev/null
node --check scripts/seo_audit.mjs >/dev/null
node --check scripts/event_audit.mjs >/dev/null

# Verify JSON inputs before rebuilding generated pages.
node -e "JSON.parse(require('fs').readFileSync('seed.json','utf8')); JSON.parse(require('fs').readFileSync('events.json','utf8')); JSON.parse(require('fs').readFileSync('performances.json','utf8'));" >/dev/null

echo "[2/5] Rebuild English and SEO pages"
node scripts/generate_en_pages.mjs
node scripts/generate_seo_pages.mjs

echo "[3/5] Audits and regression tests"
node scripts/event_audit.mjs
node scripts/performance_audit.mjs
node test_recommender.js
node test_v20_16_0_whats_on.js
node scripts/seo_audit.mjs --report seo-audit/v20.16.0-final

echo "[4/5] Stage only v20.16.0 files"
mapfile -t FILES < "$MANIFEST"
for f in "${FILES[@]}"; do
  [[ -e "$f" ]] || { echo "ERROR: expected file missing after rebuild: $f"; exit 1; }
done
git add -- "${FILES[@]}"

if git diff --cached --quiet; then
  echo "Kibun v20.16.0 is already applied; nothing to push."
  trap - ERR
  cleanup_update_files
  exit 0
fi

echo "[5/5] Commit and push"
git commit -m "Kibun v20.16.0: unified What's On events"
git push origin main

trap - ERR
cleanup_update_files
echo "Kibun v20.16.0 pushed. Cloudflare will deploy automatically from GitHub."
