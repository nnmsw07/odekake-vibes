const fs=require('fs');
const vm=require('vm');
const code=fs.readFileSync('app.js','utf8');
if(!code.includes('instagramSearchUrl')) throw new Error('instagramSearchUrl missing');
if(!code.includes('Instagramでこのスポットを検索')) throw new Error('CTA missing');
if(!code.includes("link_type:'instagram_search'")) throw new Error('tracking missing');
if(!fs.readFileSync('index.html','utf8').includes('app.js?v=2065')) throw new Error('cache buster missing');
console.log('v20.6.5 Instagram search static checks: OK');
