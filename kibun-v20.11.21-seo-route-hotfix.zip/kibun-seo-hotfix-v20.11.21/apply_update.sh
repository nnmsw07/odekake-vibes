#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(git rev-parse --show-toplevel)"
cd "$ROOT"

mkdir -p scripts
cp "$HERE/scripts/generate_seo_pages.mjs" scripts/generate_seo_pages.mjs
cp "$HERE/CHANGELOG_v20_11_21.md" CHANGELOG_v20_11_21.md

node --check scripts/generate_seo_pages.mjs
node scripts/generate_seo_pages.mjs

# 以前の更新で spots/ が .gitignore 等により取りこぼされても、今回は確実に追跡する。
git add scripts/generate_seo_pages.mjs CHANGELOG_v20_11_21.md sitemap.xml robots.txt _redirects spots-index.html
git add -f spots
find . -maxdepth 1 -type f -name 'seo-spot-*.html' -print0 | xargs -0 git add -f --

# push 前セルフチェック
[ -f spots/index.html ]
[ -f spots-index.html ]
[ -f _redirects ]
grep -q '^/spots/ /spots-index.html 200$' _redirects
TARGET="$(find . -maxdepth 1 -type f -name 'seo-spot-*.html' | head -n 1)"
[ -n "$TARGET" ] && [ -s "$TARGET" ]
COUNT="$(find . -maxdepth 1 -type f -name 'seo-spot-*.html' | wc -l | tr -d ' ')"
if [ "$COUNT" -lt 50 ]; then
  echo "SEO fallback pages が少なすぎます: $COUNT" >&2
  exit 1
fi

echo "SEO fallback pages: $COUNT"
if git diff --cached --quiet; then
  echo "変更はありません。"
  exit 0
fi

git commit -m "fix: make SEO spot routes deploy-safe"
git push origin HEAD
echo "完了: push 後は Cloudflare の GitHub 連携で自動デプロイされます。"
echo "確認URL: https://kibuntrip.com/spots/"
