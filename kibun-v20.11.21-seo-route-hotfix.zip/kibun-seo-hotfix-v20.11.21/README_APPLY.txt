Kibun v20.11.21 SEO route hotfix

前回の v20.11.20 適用後に /spots/ が 404 になった場合の修正版です。
Cloudflare の手動ログインや wrangler deploy は行いません。
push 後は既存の GitHub → Cloudflare 自動デプロイを利用します。
