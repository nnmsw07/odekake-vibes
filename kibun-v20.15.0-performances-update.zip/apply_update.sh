#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
MANIFEST="UPDATE_MANIFEST_v20_15_0.txt"

[[ -d .git ]] || { echo "ERROR: run this from the Kibun repository root in Codespaces."; exit 1; }
[[ -f "$MANIFEST" ]] || { echo "ERROR: $MANIFEST not found."; exit 1; }
for f in seed.json data.js performances.json performances.js index.html en/index.html scripts/performance_audit.mjs test_v20_15_0_performances.js; do
  [[ -f "$f" ]] || { echo "ERROR: update file missing: $f"; exit 1; }
done

echo "[1/5] Syntax checks"
node --check app.js >/dev/null
node --check en/app.js >/dev/null
node --check performances/app.js >/dev/null
node --check en/performances/app.js >/dev/null
node --check scripts/generate_en_pages.mjs >/dev/null
node --check scripts/generate_seo_pages.mjs >/dev/null
node --check scripts/seo_audit.mjs >/dev/null
node --check scripts/performance_audit.mjs >/dev/null
python - <<'PYCODE'
from pathlib import Path
for f in ['scripts/apply_v20_15_performances.py','scripts/build_v20_14_en_editorial.py']:
    compile(Path(f).read_text(), f, 'exec')
PYCODE

echo "[2/5] Rebuild English/editorial and SEO pages"
python scripts/build_v20_14_en_editorial.py
node scripts/generate_en_pages.mjs
node scripts/generate_seo_pages.mjs

echo "[3/5] Audits and tests"
node scripts/performance_audit.mjs
node test_recommender.js
node test_v20_15_0_performances.js
node scripts/seo_audit.mjs --report seo-audit/v20.15.0-final

echo "[4/5] Stage only v20.15.0 files"
mapfile -t FILES < "$MANIFEST"
for f in "${FILES[@]}"; do
  [[ -e "$f" ]] || { echo "ERROR: generated file missing: $f"; exit 1; }
done
git add -- "${FILES[@]}"

cleanup_update_files() {
  for f in "$MANIFEST" "$0"; do
    if git ls-files --error-unmatch "$f" >/dev/null 2>&1; then
      git restore --source=HEAD -- "$f"
    else
      rm -f "$f"
    fi
  done
}

if git diff --cached --quiet; then
  echo "Kibun v20.15.0 is already applied; nothing to push."
  cleanup_update_files
  exit 0
fi

echo "[5/5] Commit and push"
git commit -m "Kibun v20.15.0: performances and English expansion"
git push origin main

cleanup_update_files
echo "Kibun v20.15.0 pushed. Cloudflare will deploy automatically from GitHub."
