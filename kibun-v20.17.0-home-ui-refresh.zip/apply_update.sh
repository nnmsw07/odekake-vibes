#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
MANIFEST="UPDATE_MANIFEST_v20_17_0.txt"
ARCHIVE="kibun-v20.17.0-home-ui-refresh.zip"

[[ -d .git ]] || { echo "ERROR: run this from the Kibun repository root in Codespaces."; exit 1; }
[[ -f "$MANIFEST" ]] || { echo "ERROR: $MANIFEST not found."; exit 1; }
for f in index.html en/index.html styles.css test_v20_17_0_home_ui.js; do
  [[ -f "$f" ]] || { echo "ERROR: update file missing: $f"; exit 1; }
done

cleanup_update_files() {
  for f in "$MANIFEST" "$0" "$ARCHIVE"; do
    [[ -e "$f" ]] || continue
    if git ls-files --error-unmatch "$f" >/dev/null 2>&1; then
      git restore --source=HEAD -- "$f"
    else
      rm -f "$f"
    fi
  done
}
trap 'echo "Update stopped before push because a check failed."' ERR

echo "[1/4] Syntax and UI checks"
node --check app.js >/dev/null
node --check en/app.js >/dev/null
node test_v20_17_0_home_ui.js

echo "[2/4] Regression and content audits"
node test_v20_16_0_whats_on.js
node test_recommender.js
node test_v20_11_25_ui_ogp.js
node scripts/event_audit.mjs
node scripts/performance_audit.mjs
node scripts/seo_audit.mjs

echo "[3/4] Stage v20.17.0 files"
mapfile -t FILES < "$MANIFEST"
for f in "${FILES[@]}"; do
  [[ -e "$f" ]] || { echo "ERROR: expected file missing: $f"; exit 1; }
done
git add -- "${FILES[@]}"

if git diff --cached --quiet; then
  echo "Kibun v20.17.0 is already applied; nothing to push."
  trap - ERR
  cleanup_update_files
  exit 0
fi

echo "[4/4] Commit and push"
git commit -m "Kibun v20.17.0: refine home horizontal UI"
git push origin main

trap - ERR
cleanup_update_files
echo "Kibun v20.17.0 pushed. Cloudflare will deploy automatically from GitHub."
