# Kibun v20.12.8 — Current Buzz + Yokohama family discovery

- Added ららぽーと横浜 as spot_474 (20th-anniversary renewal; family/infant/rainy-day fit).
- Added `current_buzz` to PLAY! PARK, カップヌードルミュージアム 横浜, 横浜美術館, 横浜・八景島シーパラダイス, 横浜海の公園スターバックス, and ららぽーと横浜.
- Spot detail UI now separates durable spot facts from temporary “NOW · 今行く理由”.
- Updated spot count to 474 and added SEO route, canonical page, fallback page and sitemap entry for spot_474.
- SEO audit passed for all 474 spot routes: page presence, self-canonical, indexability, sitemap inclusion and fallback page.
- Existing recommender / SNS UI regression tests passed after count update.
