#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
REPO="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cp -R "$HERE"/payload/. "$REPO"/
cd "$REPO"
node --check app.js
node --check data.js
node test_v20_12_8_current_buzz.js
node test_v20_12_8_seo_audit.js
git add data.js seed.json app.js styles.css index.html spots-index.html spots/index.html spots/routes.json sitemap.xml spots/lalaport-yokohama/index.html seo-spot-spot_474.html test_v20_12_3_seo_affiliate_similar.js test_v20_12_8_current_buzz.js test_v20_12_8_seo_audit.js CHANGELOG_v20_12_8.md
git commit -m "Add current buzz and Lalaport Yokohama" || true
git push
